# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mysql-stubs']

package_data = \
{'': ['*'], 'mysql-stubs': ['connector/*']}

setup_kwargs = {
    'name': 'mysql-connector-python-stubs',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Nils Olsson',
    'author_email': 'nilso@enosis.net',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
